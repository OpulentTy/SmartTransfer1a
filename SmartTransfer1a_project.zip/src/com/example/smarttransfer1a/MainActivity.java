package com.example.smarttransfer1a;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int PICK_FILE = 1;
    private static final int PICK_DEST = 2;

    private Uri sourceFile;
    private Uri destFolder;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button pickFile = findViewById(R.id.btnPickFile);
        Button pickDest = findViewById(R.id.btnPickDest);
        Button transfer = findViewById(R.id.btnTransfer);
        status = findViewById(R.id.status);

        pickFile.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.setType("*/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(i, PICK_FILE);
            }
        });

        pickDest.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                startActivityForResult(i, PICK_DEST);
            }
        });

        transfer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (sourceFile != null && destFolder != null) transferFile();
                else status.setText("Select source and destination first!");
            }
        });
    }

    private void transferFile() {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    ContentResolver resolver = getContentResolver();
                    String name = "copied_" + System.currentTimeMillis();
                    Uri parentDoc = DocumentsContract.buildDocumentUriUsingTree(destFolder, DocumentsContract.getTreeDocumentId(destFolder));
                    Uri newFile = DocumentsContract.createDocument(resolver, parentDoc, "*/*", name);
                    InputStream in = resolver.openInputStream(sourceFile);
                    OutputStream out = resolver.openOutputStream(newFile);
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                    in.close();
                    out.close();
                    runOnUiThread(new Runnable() { @Override public void run() { status.setText("File transferred successfully!"); } });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() { @Override public void run() { status.setText("Error: " + e.getMessage()); } });
                }
            }
        }).start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == PICK_FILE) {
                sourceFile = data.getData();
                status.setText("Picked file: " + sourceFile.getLastPathSegment());
            } else if (requestCode == PICK_DEST) {
                destFolder = data.getData();
                status.setText("Picked destination folder.");
            }
        }
    }
}
